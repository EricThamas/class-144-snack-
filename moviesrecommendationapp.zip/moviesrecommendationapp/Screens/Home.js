import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import * as axios from 'axios';

export default class HomeScreen extends React.Component {
  constructor() {
    super();
    this.state = { movieData: [] };
  }
  getMovie = async () => {
    const url = 'http://127.0.0.1:5000/getMovie';
    await axios
      .get(url)
      .then((r) => {
        var details = r.data.movie_data;
        console.log(details);
        this.setState({
          movieData: details,
        });
      })
      .catch((Error) => {
        console.log(Error.message);
      });
  };
  likedMovies = async () => {
    const url = 'http://127.0.0.1:5000/likedMovies';
    await axios
      .post(url)
      .then((r) => {
        this.getMovie();
      })
      .catch((Error) => {
        console.log(Error.message);
      });
  };
  didnotlikeMovies = async () => {
    const url = 'http://127.0.0.1:5000/didnotlikeMovies';
    await axios
      .post(url)
      .then((r) => {
        this.getMovie();
      })
      .catch((Error) => {
        console.log(Error.message);
      });
  };
  didnot = async () => {
    const url = 'http://127.0.0.1:5000/didnot';
    await axios
      .post(url)
      .then((r) => {
        this.getMovie();
      })
      .catch((Error) => {
        console.log(Error.message);
      });
  };
  componentDidMount() {
    this.getMovie();
  }
  render() {
    return <View style={{ flex: 1, backgroundColor: 'black' }}></View>;
  }
}
