import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default class RecommendationScreen extends React.Component{
  render(){
    return(
      <View></View>
    )
  }
}

