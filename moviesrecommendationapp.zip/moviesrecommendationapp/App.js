import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import HomeScreen from "./Screens/Home"

export default class RecommendationApp extends React.Component{
  render(){
    return(
      <HomeScreen/>
    )
  }
}

